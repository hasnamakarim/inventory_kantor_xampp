document.addEventListener("DOMContentLoaded", function () {
    fetch("process/fetch_inventaris.php")
        .then((res) => res.text())
        .then((data) => {
            document.getElementById("data-inventaris").innerHTML = data;
        });
});
