<?php
include '../config/db.php';
$sql = "SELECT * FROM inventaris";
$result = $conn->query($sql);
$no = 1;
while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$no}</td>
        <td>{$row['kode_label']}</td>
        <td>{$row['nomor_seri']}</td>
        <td>{$row['nama_barang']}</td>
        <td>{$row['status']}</td>
        <td>{$row['lokasi']}</td>
        <td>
            <button class='btn'>Pemeliharaan</button>
            <button class='btn'>Resume</button>
            <button class='btn'>Edit</button>
        </td>
    </tr>";
    $no++;
}
?>
