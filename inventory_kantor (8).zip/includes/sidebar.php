<div class="sidebar">
    <h2>Inventory Kantor</h2>
    <a href="#">Home</a>
    <a href="#">Data Petugas</a>
    <a href="#">Data Pegawai</a>
    <a href="#">Data Supplier</a>
    <a href="#">Data Departemen</a>
    <a href="#">Data Lokasi</a>
    <a href="#">Data Kategori</a>
    <a href="#">Data Barang</a>
    <a href="#">Data Inventaris</a>
    <a href="#">Tool Cetak Label</a>
    <a href="#">Tool Cari Aset</a>
    <a href="#">Transaksi Pengadaan</a>
</div>
