<!DOCTYPE html>
<html>
<head>
    <title>Inventory Kantor</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
