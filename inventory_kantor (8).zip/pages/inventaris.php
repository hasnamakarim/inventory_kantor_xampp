<div class="main-content">
  <h1>DATA INVENTARIS (ASET)</h1>
  <div class="filter">
    <label>Kategori:</label>
    <select>
      <option value="semua">Semua</option>
    </select>
    <button>Tampil</button>
  </div>
  <table>
    <thead>
      <tr>
        <th>No</th>
        <th>Kode Label</th>
        <th>Nomor Seri</th>
        <th>Nama Barang</th>
        <th>Status</th>
        <th>Lokasi</th>
        <th>Tools</th>
      </tr>
    </thead>
    <tbody id="data-inventaris"></tbody>
  </table>
</div>
<script src="assets/js/script.js"></script>
