
CREATE DATABASE IF NOT EXISTS inventory_kantor;
USE inventory_kantor;

CREATE TABLE IF NOT EXISTS inventaris (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode_label VARCHAR(50),
    nomor_seri VARCHAR(50),
    nama_barang VARCHAR(100),
    status VARCHAR(50),
    lokasi VARCHAR(100)
);

INSERT INTO inventaris (kode_label, nomor_seri, nama_barang, status, lokasi) VALUES
('INV001', 'SN001', 'Laptop Lenovo', 'Aktif', 'Ruang IT'),
('INV002', 'SN002', 'Printer Epson', 'Rusak', 'Ruang Admin'),
('INV003', 'SN003', 'Proyektor BenQ', 'Dipinjam', 'Ruang Meeting');
