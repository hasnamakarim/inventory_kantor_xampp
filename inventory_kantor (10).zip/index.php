<?php
$barang = [
  ["B0001", "123456", "Printer Canon IP 2770", "Ditempatkan", "Ruang Dosen TI"],
  ["B0002", "234567", "Printer Canon IP 2770", "Ditempatkan", "Ruang Dosen SI"],
  ["B0003", "345678", "Printer Canon IP 2770", "Tersedia", "Gudang"],
  ["B0004", "456789", "Canon LBP 5100", "Tersedia", "Gudang"],
  ["B0005", "567890", "Laptop ASUS", "Ditempatkan", "TI"],
  ["B0006", "678901", "Monitor LG", "Tersedia", "SI"],
  ["B0007", "789012", "Keyboard Logitech", "Tersedia", "Gudang"],
  ["B0008", "890123", "Mouse Logitech", "Ditempatkan", "TI"],
  ["B0009", "901234", "Toshiba C40-A106", "Tersedia", "MI"],
  ["B0010", "012345", "Toshiba C40-A106", "Ditempatkan", "MI"]
];
?>
<!DOCTYPE html>
<html>
<head>
  <title>Inventory Kantor</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
  <div class="sidebar">
    <img src="logo.png" alt="Logo Hasna Makarim">
    <h2>Inventory Kantor</h2>
    <a href="#">Home</a>
    <a href="#">Data Petugas</a>
    <a href="#">Data Pegawai</a>
    <a href="#">Data Supplier</a>
    <a href="#">Data Departemen</a>
    <a href="#">Data Lokasi</a>
    <a href="#">Data Kategori</a>
    <a href="#">Data Barang</a>
    <a href="#">Data Inventaris</a>
    <a href="#">Tool Cetak Label</a>
    <a href="#">Tool Cari Aset</a>
    <a href="#">Transaksi Pengadaan</a>
  </div>
  <div class="content">
    <h2>Selamat Datang di Sistem Inventaris Kantor</h2>
    <h1>DATA INVENTARIS (ASET)</h1>
    <table>
      <thead>
        <tr>
          <th>No</th>
          <th>Kode Label</th>
          <th>Nomor Seri</th>
          <th>Nama Barang</th>
          <th>Status</th>
          <th>Lokasi</th>
          <th>Tools</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $no = 1;
        foreach ($barang as $b) {
          echo "<tr>
            <td>{$no}</td>
            <td>{$b[0]}</td>
            <td>{$b[1]}</td>
            <td>{$b[2]}</td>
            <td>{$b[3]}</td>
            <td>{$b[4]}</td>
            <td>
              <button class='button pink'>Pemeliharaan</button>
              <button class='button outline'>Resume</button>
              <button class='button outline'>Edit</button>
            </td>
          </tr>";
          $no++;
        }
        ?>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>