
CREATE DATABASE IF NOT EXISTS inventory_kantor;
USE inventory_kantor;

DROP TABLE IF EXISTS inventaris;
CREATE TABLE inventaris (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode_label VARCHAR(50),
    nomor_seri VARCHAR(100),
    nama_barang VARCHAR(100),
    status VARCHAR(50),
    lokasi VARCHAR(100)
);

INSERT INTO inventaris (kode_label, nomor_seri, nama_barang, status, lokasi) VALUES
('B0001', 'SN123456', 'Laptop Dell Latitude 7490', 'Tersedia', 'Ruang IT'),
('B0002', 'SN123457', 'Printer Canon IP2770', 'Ditempatkan', 'Ruang TU'),
('B0003', 'SN123458', 'Proyektor Epson X200', 'Tersedia', 'Gudang'),
('B0004', 'SN123459', 'Meja Kantor Kayu', 'Ditempatkan', 'Ruang Kepala'),
('B0005', 'SN123460', 'Kursi Ergonomis', 'Tersedia', 'Ruang Meeting'),
('B0006', 'SN123461', 'AC Panasonic 1PK', 'Ditempatkan', 'Ruang Kelas 1'),
('B0007', 'SN123462', 'Scanner Epson L3150', 'Tersedia', 'Ruang Arsip'),
('B0008', 'SN123463', 'Monitor LG 24"', 'Ditempatkan', 'Ruang Multimedia'),
('B0009', 'SN123464', 'Keyboard Logitech K120', 'Tersedia', 'Gudang'),
('B0010', 'SN123465', 'Mouse Wireless Logitech', 'Ditempatkan', 'Ruang Dosen');
